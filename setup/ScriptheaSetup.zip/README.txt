README

Scripthea is a free, open-source Windows application designed to streamline the process of crafting prompts for text-to-image AI generators like Stable Diffusion. 
Developed by Teodor Krastev, Scripthea offers a structured environment for building, testing, and refining prompts, making it an invaluable tool for artists, 
designers, and AI enthusiasts seeking greater control over their creative outputs. At its core, Scripthea simplifies prompt engineering by breaking down prompts 
into two components: cues (descriptive text or phrase) and modifiers (attributes like style, lighting, or artist references). This modular approach allows users to 
experiment with various combinations, facilitating a more systematic exploration of visual styles and themes.

 Why choose Scripthea?
Scripthea stands out by offering a structured approach to prompt engineering, enabling users to: 
- Systematically explore various artistic styles and themes
- Efficiently manage and review large batches of generated images.
- Gain deeper insights into the relationship between prompts and visual outputs.
Whether you're a seasoned AI artist or a newcomer eager to delve into text-to-image generation, Scripthea provides the tools and structure to elevate your creative process.

To install run ScriptheaSetup.exe and follow instructions.

For more information and contact point visit the online help at https://scripthea.com/
The sources (https://github.com/teodor-krastev/scripthea) are distributed under MIT's open source license. 

Scripthea software has been written by and is copyrighted to Teodor Krastev. 
