from craiyon.craiyon import Craiyon, CraiyonV1

__author__ = "FireHead90544"
__version__ = "1.2.0"
